# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0003_auto_20151105_0257'),
    ]

    operations = [
        migrations.AddField(
            model_name='purchase',
            name='userID',
            field=models.ForeignKey(default=1, to='core.User'),
            preserve_default=False,
        ),
    ]
