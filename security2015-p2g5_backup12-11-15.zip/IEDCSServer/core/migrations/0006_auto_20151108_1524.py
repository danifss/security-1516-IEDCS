# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0005_auto_20151107_0017'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='user',
            name='playerID',
        ),
        migrations.AddField(
            model_name='player',
            name='userId',
            field=models.ForeignKey(default=1, to='core.User'),
            preserve_default=False,
        ),
    ]
